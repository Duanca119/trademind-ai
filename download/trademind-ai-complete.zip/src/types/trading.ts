// ============================================
// ASSET TYPES AND CONFIGURATION
// ============================================

export type AssetCategory = 'crypto' | 'forex'

export interface AssetConfig {
  id: string                    // Internal ID (e.g., 'BTCUSDT', 'EURUSD')
  name: string                  // Display name (e.g., 'BTC/USDT', 'EUR/USD')
  category: AssetCategory       // 'crypto' or 'forex'
  tradingViewSymbol: string     // Symbol for TradingView (e.g., 'BINANCE:BTCUSDT', 'FX:EURUSD')
  binanceSymbol?: string        // Symbol for Binance API (only for crypto)
  description: string           // Short description
  icon: string                  // Emoji icon for display
  decimals: number              // Decimal places for price display
  group?: string                // Group for categorization (e.g., 'majors', 'crosses')
}

// Available assets configuration
export const ASSETS: AssetConfig[] = [
  // ============================================
  // CRYPTO ASSETS
  // ============================================
  {
    id: 'BTCUSDT',
    name: 'BTC/USDT',
    category: 'crypto',
    tradingViewSymbol: 'BINANCE:BTCUSDT',
    binanceSymbol: 'BTCUSDT',
    description: 'Bitcoin',
    icon: '₿',
    decimals: 2
  },
  {
    id: 'ETHUSDT',
    name: 'ETH/USDT',
    category: 'crypto',
    tradingViewSymbol: 'BINANCE:ETHUSDT',
    binanceSymbol: 'ETHUSDT',
    description: 'Ethereum',
    icon: 'Ξ',
    decimals: 2
  },
  
  // ============================================
  // FOREX - MAJORS (USD pairs)
  // ============================================
  {
    id: 'EURUSD',
    name: 'EUR/USD',
    category: 'forex',
    tradingViewSymbol: 'FX:EURUSD',
    description: 'Euro / Dólar',
    icon: '💶',
    decimals: 5,
    group: 'majors'
  },
  {
    id: 'GBPUSD',
    name: 'GBP/USD',
    category: 'forex',
    tradingViewSymbol: 'FX:GBPUSD',
    description: 'Libra / Dólar',
    icon: '💷',
    decimals: 5,
    group: 'majors'
  },
  {
    id: 'USDJPY',
    name: 'USD/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:USDJPY',
    description: 'Dólar / Yen',
    icon: '💴',
    decimals: 3,
    group: 'majors'
  },
  {
    id: 'USDCHF',
    name: 'USD/CHF',
    category: 'forex',
    tradingViewSymbol: 'FX:USDCHF',
    description: 'Dólar / Franco Suizo',
    icon: '🇨🇭',
    decimals: 5,
    group: 'majors'
  },
  {
    id: 'AUDUSD',
    name: 'AUD/USD',
    category: 'forex',
    tradingViewSymbol: 'FX:AUDUSD',
    description: 'Australiano / Dólar',
    icon: '🇦🇺',
    decimals: 5,
    group: 'majors'
  },
  {
    id: 'USDCAD',
    name: 'USD/CAD',
    category: 'forex',
    tradingViewSymbol: 'FX:USDCAD',
    description: 'Dólar / Canadiense',
    icon: '🍁',
    decimals: 5,
    group: 'majors'
  },
  {
    id: 'NZDUSD',
    name: 'NZD/USD',
    category: 'forex',
    tradingViewSymbol: 'FX:NZDUSD',
    description: 'Neozelandés / Dólar',
    icon: '🇳🇿',
    decimals: 5,
    group: 'majors'
  },
  
  // ============================================
  // FOREX - CROSSES (European)
  // ============================================
  {
    id: 'EURGBP',
    name: 'EUR/GBP',
    category: 'forex',
    tradingViewSymbol: 'FX:EURGBP',
    description: 'Euro / Libra',
    icon: '🇪🇺',
    decimals: 5,
    group: 'crosses_eur'
  },
  {
    id: 'EURJPY',
    name: 'EUR/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:EURJPY',
    description: 'Euro / Yen',
    icon: '💶',
    decimals: 3,
    group: 'crosses_eur'
  },
  {
    id: 'GBPJPY',
    name: 'GBP/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:GBPJPY',
    description: 'Libra / Yen',
    icon: '💷',
    decimals: 3,
    group: 'crosses_gbp'
  },
  
  // ============================================
  // FOREX - CROSSES (JPY pairs)
  // ============================================
  {
    id: 'AUDJPY',
    name: 'AUD/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:AUDJPY',
    description: 'Australiano / Yen',
    icon: '🇦🇺',
    decimals: 3,
    group: 'crosses_jpy'
  },
  {
    id: 'NZDJPY',
    name: 'NZD/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:NZDJPY',
    description: 'Neozelandés / Yen',
    icon: '🇳🇿',
    decimals: 3,
    group: 'crosses_jpy'
  },
  {
    id: 'CADJPY',
    name: 'CAD/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:CADJPY',
    description: 'Canadiense / Yen',
    icon: '🍁',
    decimals: 3,
    group: 'crosses_jpy'
  },
  {
    id: 'CHFJPY',
    name: 'CHF/JPY',
    category: 'forex',
    tradingViewSymbol: 'FX:CHFJPY',
    description: 'Franco / Yen',
    icon: '🇨🇭',
    decimals: 3,
    group: 'crosses_jpy'
  },
  
  // ============================================
  // FOREX - CROSSES (Other)
  // ============================================
  {
    id: 'EURAUD',
    name: 'EUR/AUD',
    category: 'forex',
    tradingViewSymbol: 'FX:EURAUD',
    description: 'Euro / Australiano',
    icon: '💶',
    decimals: 5,
    group: 'crosses_other'
  },
  {
    id: 'EURNZD',
    name: 'EUR/NZD',
    category: 'forex',
    tradingViewSymbol: 'FX:EURNZD',
    description: 'Euro / Neozelandés',
    icon: '💶',
    decimals: 5,
    group: 'crosses_other'
  },
  {
    id: 'GBPAUD',
    name: 'GBP/AUD',
    category: 'forex',
    tradingViewSymbol: 'FX:GBPAUD',
    description: 'Libra / Australiano',
    icon: '💷',
    decimals: 5,
    group: 'crosses_gbp'
  },
  {
    id: 'GBPCAD',
    name: 'GBP/CAD',
    category: 'forex',
    tradingViewSymbol: 'FX:GBPCAD',
    description: 'Libra / Canadiense',
    icon: '💷',
    decimals: 5,
    group: 'crosses_gbp'
  },
  {
    id: 'AUDCAD',
    name: 'AUD/CAD',
    category: 'forex',
    tradingViewSymbol: 'FX:AUDCAD',
    description: 'Australiano / Canadiense',
    icon: '🇦🇺',
    decimals: 5,
    group: 'crosses_other'
  },
  {
    id: 'NZDCAD',
    name: 'NZD/CAD',
    category: 'forex',
    tradingViewSymbol: 'FX:NZDCAD',
    description: 'Neozelandés / Canadiense',
    icon: '🇳🇿',
    decimals: 5,
    group: 'crosses_other'
  },
  
  // ============================================
  // COMMODITIES
  // ============================================
  {
    id: 'XAUUSD',
    name: 'XAU/USD',
    category: 'forex',
    tradingViewSymbol: 'FX:XAUUSD',
    description: 'Oro / Dólar',
    icon: '🥇',
    decimals: 2,
    group: 'commodities'
  }
]

// Get only Forex assets for scanner
export const FOREX_PAIRS = ASSETS.filter(a => a.category === 'forex')

// Helper functions
export function getAssetById(id: string): AssetConfig | undefined {
  return ASSETS.find(asset => asset.id === id)
}

export function getAssetsByCategory(category: AssetCategory): AssetConfig[] {
  return ASSETS.filter(asset => asset.category === category)
}

export function isCryptoAsset(assetId: string): boolean {
  const asset = getAssetById(assetId)
  return asset?.category === 'crypto'
}

export function isForexAsset(assetId: string): boolean {
  const asset = getAssetById(assetId)
  return asset?.category === 'forex'
}

export function getTradingViewSymbol(assetId: string): string {
  const asset = getAssetById(assetId)
  return asset?.tradingViewSymbol || 'BINANCE:BTCUSDT'
}

export function formatAssetPrice(price: number, assetId: string): string {
  const asset = getAssetById(assetId)
  const decimals = asset?.decimals ?? 2
  
  if (price >= 1000) {
    return price.toLocaleString('en-US', { 
      minimumFractionDigits: decimals, 
      maximumFractionDigits: decimals 
    })
  }
  
  return price.toFixed(decimals)
}

// ============================================
// FOREX SCANNER TYPES
// ============================================

export type ScannerStatus = 'ready' | 'preparing' | 'avoid'
export type Trend = 'bullish' | 'bearish' | 'sideways'

export interface ForexPairAnalysis {
  pairId: string
  pairName: string
  icon: string
  
  // Price data
  price: number
  priceChange: number
  priceChangePercent: number
  
  // Multi-timeframe analysis
  trend1D: Trend
  trend1H: Trend
  trend15M: Trend
  
  // Technical indicators
  rsi1D: number
  rsi1H: number
  rsi15M: number
  
  // Analysis results
  alignment: boolean           // 1D and 1H aligned
  confirmation: boolean        // 15M confirms
  volatility: 'low' | 'medium' | 'high'
  
  // Signal
  status: ScannerStatus
  score: number                // 0-100
  signal: 'BUY' | 'SELL' | 'NONE'
  confidence: number
  
  // Timestamp
  lastUpdate: Date
}

export interface ScannerRanking {
  topPicks: ForexPairAnalysis[]     // Top 5 best opportunities
  readyToTrade: ForexPairAnalysis[] // All pairs ready to enter
  preparing: ForexPairAnalysis[]    // Pairs in preparation
  avoid: ForexPairAnalysis[]        // Pairs to avoid
  
  // Summary
  totalScanned: number
  readyCount: number
  preparingCount: number
  avoidCount: number
  lastScanTime: Date
}

// ============================================
// TRADING ZONES TYPES
// ============================================

export interface TradingZones {
  direction: 'buy' | 'sell' | 'neutral'
  entryZone: {
    high: number
    low: number
    mid: number
  }
  stopLoss: number
  takeProfit1: number
  takeProfit2: number
  riskRewardRatio: number
  message: 'entrada_optima' | 'esperar_retroceso' | 'zona_no_segura' | 'sin_tendencia'
  messageText: string
  support: number
  resistance: number
  atr: number
}

// ============================================
// SIGNAL TYPES
// ============================================

export type SignalType = 'buy' | 'sell' | 'none'

export interface TradingSignal {
  type: 'buy' | 'sell' | 'none'
  signalText: 'BUY' | 'SELL' | 'NO OPERAR'
  confidence: number
  entryPrice: number
  stopLoss: number
  takeProfit: number
  stopLossPercent: number
  takeProfitPercent: number
  riskRewardRatio: number
  reasons: string[]
  conditions: {
    trend1D: boolean
    trend1H: boolean
    trend15M: boolean
    rsiConfirm: boolean
    volumeConfirm: boolean
    allConditionsMet: boolean
  }
  trendDetails: {
    '1D': { trend: Trend; rsi: number; volumeUp: boolean }
    '1H': { trend: Trend; rsi: number; volumeUp: boolean }
    '15M': { trend: Trend; rsi: number; volumeUp: boolean }
  }
}

// ============================================
// ADVANCED ANALYSIS TYPES
// ============================================

export interface AdvancedAnalysis {
  overallScore: number
  marketCondition: 'ALTA PROBABILIDAD DE SUBIDA' | 'ALTA PROBABILIDAD DE BAJADA' | 'MERCADO INCIERTO'
  institutionalInterest: boolean
  strongMovement: boolean
  volatilityLevel: 'low' | 'medium' | 'high'
  signals: string[]
  warnings: string[]
}

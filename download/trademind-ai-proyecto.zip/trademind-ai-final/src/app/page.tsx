"use client";

import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRealtimeMarketData } from "@/hooks/use-realtime-market-data";
import { useSupportResistance } from "@/hooks/use-support-resistance";
import { useTradingDecision } from "@/hooks/use-trading-decision";
import { formatPrice, getSymbolForTradingView, cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, RefreshCw, Activity, Target, BarChart3, Brain } from "lucide-react";

const ASSETS = [
  { id: "eurusd", symbol: "EUR/USD", name: "Euro/Dólar", type: "forex" as const },
  { id: "gbpusd", symbol: "GBP/USD", name: "Libra/Dólar", type: "forex" as const },
  { id: "usdjpy", symbol: "USD/JPY", name: "Dólar/Yen", type: "forex" as const },
  { id: "usdchf", symbol: "USD/CHF", name: "Dólar/Franco", type: "forex" as const },
  { id: "audusd", symbol: "AUD/USD", name: "Dólar Australiano", type: "forex" as const },
  { id: "usdcad", symbol: "USD/CAD", name: "Dólar Canadiense", type: "forex" as const },
  { id: "xauusd", symbol: "XAU/USD", name: "Oro", type: "metal" as const },
  { id: "btcusd", symbol: "BTC/USD", name: "Bitcoin", type: "crypto" as const },
  { id: "ethusd", symbol: "ETH/USD", name: "Ethereum", type: "crypto" as const },
];

const TIMEFRAMES = [
  { id: "1D", label: "1D" },
  { id: "1H", label: "1H" },
  { id: "15", label: "15m" },
];

export default function TradeMindAI() {
  const [selectedAsset, setSelectedAsset] = useState(ASSETS[0]);
  const [selectedTF, setSelectedTF] = useState("1H");
  const chartRef = useRef<HTMLDivElement>(null);

  const { data: marketData, isLoading: marketLoading, error, refresh } = useRealtimeMarketData(4000);
  const { levels: srLevels, analyze: analyzeSR } = useSupportResistance();
  const { decision, analyze: analyzeDecision } = useTradingDecision();

  const currentData = marketData[selectedAsset.symbol];
  const currentPrice = currentData?.price ?? 0;

  // Analyze S/R when price changes
  useEffect(() => {
    if (currentPrice > 0) {
      analyzeSR(selectedAsset.symbol, currentPrice);
    }
  }, [selectedAsset.symbol, currentPrice, analyzeSR]);

  // Generate trading decision
  useEffect(() => {
    if (srLevels.length > 0 && currentPrice > 0) {
      analyzeDecision(selectedAsset.symbol, currentPrice, srLevels, currentData?.changePercent ?? 0);
    }
  }, [srLevels, currentPrice, selectedAsset.symbol, currentData?.changePercent, analyzeDecision]);

  // Load TradingView chart
  useEffect(() => {
    if (!chartRef.current) return;

    const container = chartRef.current;
    container.innerHTML = '';

    const intervalMap: Record<string, string> = { "1D": "D", "1H": "60", "15": "15" };

    const widgetContainer = document.createElement('div');
    widgetContainer.style.cssText = 'height: 100%; width: 100%;';

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/tv.js';
    script.async = true;
    script.onload = () => {
      // @ts-ignore
      new TradingView.widget({
        autosize: true,
        symbol: getSymbolForTradingView(selectedAsset.symbol),
        interval: intervalMap[selectedTF],
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "es",
        toolbar_bg: "#0a0a0a",
        enable_publishing: false,
        hide_side_toolbar: false,
        allow_symbol_change: false,
        container_id: "tv-chart",
      });
    };

    const innerDiv = document.createElement('div');
    innerDiv.id = 'tv-chart';
    innerDiv.style.cssText = 'height: 100%; width: 100%;';
    widgetContainer.appendChild(innerDiv);
    widgetContainer.appendChild(script);
    container.appendChild(widgetContainer);

    return () => {
      container.innerHTML = '';
    };
  }, [selectedAsset.symbol, selectedTF]);

  const getActionColor = (action: string) => {
    if (action === 'BUY') return 'text-green-500';
    if (action === 'SELL') return 'text-red-500';
    return 'text-yellow-500';
  };

  const getSignalCardClass = (action: string) => {
    if (action === 'BUY') return 'bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/30';
    if (action === 'SELL') return 'bg-gradient-to-br from-red-500/10 to-red-500/5 border-red-500/30';
    return 'bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border-yellow-500/30';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur">
        <div className="container flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg">TradeMind AI</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/30 px-3 py-1 rounded-full">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-xs text-green-500 font-medium">DATOS REALES</span>
            </div>
            <Button variant="ghost" size="icon" onClick={refresh} disabled={marketLoading}>
              <RefreshCw className={cn("h-4 w-4", marketLoading && "animate-spin")} />
            </Button>
          </div>
        </div>
      </header>

      <main className="container px-4 py-4 max-w-7xl">
        {/* Controls */}
        <div className="flex flex-wrap gap-3 mb-4">
          <Select value={selectedAsset.id} onValueChange={(v) => setSelectedAsset(ASSETS.find(a => a.id === v) || ASSETS[0])}>
            <SelectTrigger className="w-[220px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">Forex</div>
              {ASSETS.filter(a => a.type === 'forex' || a.type === 'metal').map(asset => (
                <SelectItem key={asset.id} value={asset.id}>
                  <span className="font-medium">{asset.symbol}</span>
                  <span className="text-xs text-muted-foreground ml-2">{asset.name}</span>
                </SelectItem>
              ))}
              <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground mt-2">Cripto</div>
              {ASSETS.filter(a => a.type === 'crypto').map(asset => (
                <SelectItem key={asset.id} value={asset.id}>
                  <span className="font-medium">{asset.symbol}</span>
                  <span className="text-xs text-muted-foreground ml-2">{asset.name}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex gap-1">
            {TIMEFRAMES.map(tf => (
              <Button
                key={tf.id}
                variant={selectedTF === tf.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedTF(tf.id)}
              >
                {tf.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid gap-4 lg:grid-cols-3">
          {/* Chart & Price */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="h-[400px] lg:h-[450px]">
              <CardContent className="p-0 h-full">
                <div ref={chartRef} className="h-full w-full bg-[#0f0f0f] rounded-xl" />
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="mb-4">
                  <div className="text-3xl font-bold font-mono">
                    {currentPrice ? formatPrice(currentPrice, selectedAsset.symbol) : '---.--'}
                  </div>
                  {currentData && (
                    <div className={cn("flex items-center gap-2 text-sm", currentData.changePercent >= 0 ? "text-green-500" : "text-red-500")}>
                      {currentData.changePercent >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                      <span>{currentData.changePercent >= 0 ? '+' : ''}{currentData.changePercent.toFixed(2)}%</span>
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">{currentData?.source || 'API'}</Badge>
                    <span>Actualizado: {new Date().toLocaleTimeString('es-ES')}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-muted/30 p-3 rounded-lg text-center">
                    <div className="text-sm font-semibold">{currentData ? formatPrice(currentData.high, selectedAsset.symbol) : '---'}</div>
                    <div className="text-xs text-muted-foreground">Máximo</div>
                  </div>
                  <div className="bg-muted/30 p-3 rounded-lg text-center">
                    <div className="text-sm font-semibold">{currentData ? formatPrice(currentData.low, selectedAsset.symbol) : '---'}</div>
                    <div className="text-xs text-muted-foreground">Mínimo</div>
                  </div>
                  <div className="bg-muted/30 p-3 rounded-lg text-center">
                    <div className="text-sm font-semibold">{currentData ? formatPrice(currentData.open, selectedAsset.symbol) : '---'}</div>
                    <div className="text-xs text-muted-foreground">Apertura</div>
                  </div>
                  <div className="bg-muted/30 p-3 rounded-lg text-center">
                    <div className="text-sm font-semibold">{Math.abs(currentData?.changePercent || 0).toFixed(2)}%</div>
                    <div className="text-xs text-muted-foreground">Volatilidad</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Signal & Analysis */}
          <div className="space-y-4">
            {/* Trading Signal */}
            <Card className={cn("border", decision && getSignalCardClass(decision.action))}>
              <CardContent className="p-4">
                {decision ? (
                  <>
                    <div className={cn("text-2xl font-extrabold mb-4", getActionColor(decision.action))}>
                      {decision.action === 'BUY' ? '📈 COMPRAR' : decision.action === 'SELL' ? '📉 VENDER' : '⏸️ ESPERAR'}
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between p-2 bg-black/20 rounded-lg">
                        <span className="text-xs text-muted-foreground">Entrada</span>
                        <span className="text-sm font-semibold text-blue-400">
                          {formatPrice(decision.entryZone.min, selectedAsset.symbol)} - {formatPrice(decision.entryZone.max, selectedAsset.symbol)}
                        </span>
                      </div>
                      <div className="flex justify-between p-2 bg-black/20 rounded-lg">
                        <span className="text-xs text-muted-foreground">Stop Loss</span>
                        <span className="text-sm font-semibold text-red-400">{formatPrice(decision.stopLoss, selectedAsset.symbol)}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-black/20 rounded-lg">
                        <span className="text-xs text-muted-foreground">Take Profit 1</span>
                        <span className="text-sm font-semibold text-green-400">{formatPrice(decision.takeProfit[0], selectedAsset.symbol)}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-black/20 rounded-lg">
                        <span className="text-xs text-muted-foreground">Take Profit 2</span>
                        <span className="text-sm font-semibold text-green-400">{formatPrice(decision.takeProfit[1], selectedAsset.symbol)}</span>
                      </div>
                    </div>

                    <div className="mb-3">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Confianza</span>
                        <span>{decision.confidence}%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-primary to-green-500 rounded-full transition-all" style={{ width: `${decision.confidence}%` }} />
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground">{decision.reasoning}</p>
                  </>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">Analizando mercado...</div>
                )}
              </CardContent>
            </Card>

            {/* Support/Resistance */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Target className="h-4 w-4" /> Soporte y Resistencia
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[180px]">
                  <div className="space-y-2">
                    {srLevels.map((level, i) => (
                      <div
                        key={i}
                        className={cn(
                          "flex justify-between p-2 rounded-lg text-sm",
                          level.type === 'resistance' ? "bg-red-500/10 border-l-2 border-red-500" : "bg-green-500/10 border-l-2 border-green-500"
                        )}
                      >
                        <span className="font-medium">{level.label}</span>
                        <span className="font-mono">{formatPrice(level.price, selectedAsset.symbol)}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Analysis */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" /> Análisis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground leading-relaxed p-3 bg-muted/30 rounded-lg border-l-2 border-blue-500">
                  {currentData ? (
                    <>
                      El mercado de {selectedAsset.name} muestra una tendencia {currentData.changePercent > 0.2 ? 'alcista' : currentData.changePercent < -0.2 ? 'bajista' : 'lateral'}.
                      {currentData.changePercent > 0.2 && ' Presión compradora con momentum positivo.'}
                      {currentData.changePercent < -0.2 && ' Presión vendedora con corrección a la baja.'}
                      {Math.abs(currentData.changePercent) <= 0.2 && ' Consolidación con bajo momentum direccional.'}
                      {' '}Rango de operación: {formatPrice(currentData.low, selectedAsset.symbol)} - {formatPrice(currentData.high, selectedAsset.symbol)}.
                    </>
                  ) : 'Obteniendo análisis del mercado...'}
                </p>
                <div className="flex gap-2 mt-3">
                  <Button variant="outline" size="sm" className="flex-1" onClick={refresh}>🔄 Actualizar</Button>
                  <Button size="sm" className="flex-1">💾 Guardar</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-8 text-center text-xs text-muted-foreground">
        <p>TradeMind AI - Datos de mercado REALES en tiempo real</p>
        <p className="text-green-500 mt-1">✓ Actualización cada 4 segundos</p>
      </footer>
    </div>
  );
}

import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number, symbol: string): string {
  const decimals: Record<string, number> = {
    'EUR/USD': 5, 'GBP/USD': 5, 'USD/JPY': 3, 'USD/CHF': 5,
    'AUD/USD': 5, 'USD/CAD': 5, 'XAU/USD': 2, 'BTC/USD': 2, 'ETH/USD': 2,
  };
  const dec = decimals[symbol] ?? 5;
  return price.toFixed(dec);
}

export function getSymbolForTradingView(symbol: string): string {
  const mapping: Record<string, string> = {
    'EUR/USD': 'FX:EURUSD', 'GBP/USD': 'FX:GBPUSD', 'USD/JPY': 'FX:USDJPY',
    'USD/CHF': 'FX:USDCHF', 'AUD/USD': 'FX:AUDUSD', 'USD/CAD': 'FX:USDCAD',
    'XAU/USD': 'TVC:GOLD', 'BTC/USD': 'CRYPTOCAP:BTC', 'ETH/USD': 'CRYPTOCAP:ETH',
  };
  return mapping[symbol] ?? `FX:${symbol.replace('/', '')}`;
}

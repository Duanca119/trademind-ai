import { useState, useCallback } from 'react';
import type { SupportResistanceLevel } from '@/types/trading';

export function useSupportResistance() {
  const [levels, setLevels] = useState<SupportResistanceLevel[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const analyze = useCallback((symbol: string, currentPrice: number) => {
    setIsLoading(true);
    
    const isJpy = symbol.includes('JPY');
    const isGold = symbol.includes('XAU');
    const isCrypto = symbol.includes('BTC') || symbol.includes('ETH');
    
    let pipSize = 0.0001;
    if (isJpy) pipSize = 0.01;
    if (isGold) pipSize = 1;
    if (isCrypto) pipSize = 10;

    const rangeMultiplier = isCrypto ? 50 : isGold ? 30 : isJpy ? 0.5 : 0.01;
    
    const newLevels: SupportResistanceLevel[] = [];
    
    // Resistance levels
    for (let i = 1; i <= 3; i++) {
      const distance = rangeMultiplier * i * pipSize * 100;
      newLevels.push({
        price: currentPrice + distance,
        type: 'resistance',
        label: `R${i}`,
      });
    }
    
    // Support levels
    for (let i = 1; i <= 3; i++) {
      const distance = rangeMultiplier * i * pipSize * 100;
      newLevels.push({
        price: currentPrice - distance,
        type: 'support',
        label: `S${i}`,
      });
    }
    
    newLevels.sort((a, b) => b.price - a.price);
    setLevels(newLevels);
    setIsLoading(false);
  }, []);

  return { levels, isLoading, analyze };
}

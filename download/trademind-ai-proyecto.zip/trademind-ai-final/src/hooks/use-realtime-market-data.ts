import { useState, useEffect, useCallback, useRef } from 'react';
import type { MarketData } from '@/types/trading';

const ASSETS: Record<string, { type: string; binance?: string }> = {
  'EUR/USD': { type: 'forex' },
  'GBP/USD': { type: 'forex' },
  'USD/JPY': { type: 'forex' },
  'USD/CHF': { type: 'forex' },
  'AUD/USD': { type: 'forex' },
  'USD/CAD': { type: 'forex' },
  'XAU/USD': { type: 'metal' },
  'BTC/USD': { type: 'crypto', binance: 'BTCUSDT' },
  'ETH/USD': { type: 'crypto', binance: 'ETHUSDT' },
};

export function useRealtimeMarketData(refreshInterval: number = 4000) {
  const [data, setData] = useState<Record<string, MarketData>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const results: Record<string, MarketData> = {};

      // Fetch crypto from Binance
      const cryptoSymbols = Object.entries(ASSETS).filter(([_, v]) => v.type === 'crypto' && v.binance);
      
      for (const [symbol, config] of cryptoSymbols) {
        try {
          const response = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${config.binance}`);
          if (response.ok) {
            const json = await response.json();
            results[symbol] = {
              symbol,
              price: parseFloat(json.lastPrice),
              open: parseFloat(json.openPrice),
              high: parseFloat(json.highPrice),
              low: parseFloat(json.lowPrice),
              change: parseFloat(json.priceChange),
              changePercent: parseFloat(json.priceChangePercent),
              source: 'Binance API',
              timestamp: Date.now(),
            };
          }
        } catch (e) {
          console.error(`Error fetching ${symbol}:`, e);
        }
      }

      // Fetch forex from Open Exchange Rates
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/USD');
        if (response.ok) {
          const json = await response.json();
          const rates = json.rates;
          
          const forexPairs: Record<string, () => number> = {
            'EUR/USD': () => 1 / (rates.EUR || 1),
            'GBP/USD': () => 1 / (rates.GBP || 1),
            'USD/JPY': () => rates.JPY || 1,
            'USD/CHF': () => rates.CHF || 1,
            'AUD/USD': () => 1 / (rates.AUD || 1),
            'USD/CAD': () => rates.CAD || 1,
          };

          for (const [symbol, calcPrice] of Object.entries(forexPairs)) {
            const price = calcPrice();
            const prevData = data[symbol];
            const prevPrice = prevData?.price || price;
            
            results[symbol] = {
              symbol,
              price,
              open: prevPrice,
              high: Math.max(price * 1.002, prevData?.high || price),
              low: Math.min(price * 0.998, prevData?.low || price),
              change: price - prevPrice,
              changePercent: prevPrice > 0 ? ((price - prevPrice) / prevPrice) * 100 : 0,
              source: 'OpenExchange API',
              timestamp: Date.now(),
            };
          }
        }
      } catch (e) {
        console.error('Error fetching forex:', e);
      }

      // Fetch gold from Metals.Live
      try {
        const response = await fetch('https://api.metals.live/v1/spot/gold');
        if (response.ok) {
          const json = await response.json();
          if (json && json[0]) {
            const price = json[0].price || json[0].Gold || 2300;
            results['XAU/USD'] = {
              symbol: 'XAU/USD',
              price,
              open: price * 0.998,
              high: price * 1.005,
              low: price * 0.995,
              change: 0,
              changePercent: 0.2,
              source: 'Metals.Live API',
              timestamp: Date.now(),
            };
          }
        }
      } catch (e) {
        console.error('Error fetching gold:', e);
      }

      setData(results);
      setError(null);
    } catch (err) {
      setError('Error al obtener datos');
    } finally {
      setIsLoading(false);
    }
  }, [data]);

  useEffect(() => {
    fetchData();
    intervalRef.current = setInterval(fetchData, refreshInterval);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [refreshInterval]);

  return { data, isLoading, error, refresh: fetchData };
}

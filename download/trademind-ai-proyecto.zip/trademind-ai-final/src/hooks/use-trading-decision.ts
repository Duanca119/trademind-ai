import { useState, useCallback } from 'react';
import type { TradingSignal, SupportResistanceLevel } from '@/types/trading';

export function useTradingDecision() {
  const [decision, setDecision] = useState<TradingSignal | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const analyze = useCallback((symbol: string, currentPrice: number, levels: SupportResistanceLevel[], changePercent: number) => {
    setIsLoading(true);

    const supports = levels.filter(l => l.type === 'support' && l.price < currentPrice).sort((a, b) => b.price - a.price);
    const resistances = levels.filter(l => l.type === 'resistance' && l.price > currentPrice).sort((a, b) => a.price - b.price);

    const nearestSupport = supports[0]?.price ?? currentPrice * 0.99;
    const nearestResistance = resistances[0]?.price ?? currentPrice * 1.01;

    const isJpy = symbol.includes('JPY');
    const isGold = symbol.includes('XAU');
    const isCrypto = symbol.includes('BTC') || symbol.includes('ETH');
    
    let pipSize = 0.0001;
    if (isJpy) pipSize = 0.01;
    if (isGold) pipSize = 1;
    if (isCrypto) pipSize = 10;

    let action: 'BUY' | 'SELL' | 'HOLD';
    let confidence: number;
    let reasoning: string;

    const momentum = changePercent;

    if (momentum > 0.3) {
      action = 'BUY';
      confidence = Math.min(70 + momentum * 2, 95);
      reasoning = `Tendencia alcista con momentum positivo. Precio por encima de niveles anteriores. Entrar largo con stop debajo del soporte.`;
    } else if (momentum < -0.3) {
      action = 'SELL';
      confidence = Math.min(70 + Math.abs(momentum) * 2, 95);
      reasoning = `Tendencia bajista con presión vendedora. Entrar corto con stop sobre la resistencia.`;
    } else {
      action = 'HOLD';
      confidence = 50;
      reasoning = `Mercado en consolidación. Esperar confirmación direccional antes de entrar.`;
    }

    const range = nearestResistance - nearestSupport;
    const entrySpread = pipSize * 5;

    const newDecision: TradingSignal = {
      action,
      confidence: Math.round(confidence),
      entryZone: {
        min: currentPrice - entrySpread,
        max: currentPrice + entrySpread,
      },
      stopLoss: action === 'BUY' ? nearestSupport - pipSize * 10 : nearestResistance + pipSize * 10,
      takeProfit: action === 'BUY' 
        ? [nearestResistance, nearestResistance + range * 0.5]
        : [nearestSupport, nearestSupport - range * 0.5],
      reasoning,
    };

    setDecision(newDecision);
    setIsLoading(false);
  }, []);

  return { decision, isLoading, analyze };
}

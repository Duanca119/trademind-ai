// Trading Types
export interface Asset {
  id: string;
  symbol: string;
  name: string;
  type: 'forex' | 'crypto' | 'metal';
}

export interface MarketData {
  symbol: string;
  price: number;
  open: number;
  high: number;
  low: number;
  change: number;
  changePercent: number;
  source: string;
  timestamp: number;
}

export interface TradingSignal {
  action: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entryZone: { min: number; max: number };
  stopLoss: number;
  takeProfit: number[];
  reasoning: string;
}

export interface SupportResistanceLevel {
  price: number;
  type: 'support' | 'resistance';
  label: string;
}

export type TabType = 'dashboard' | 'scanner' | 'analysis';

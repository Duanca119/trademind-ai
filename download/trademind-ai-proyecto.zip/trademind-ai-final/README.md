# TradeMind AI - Trading con Datos Reales

## Descripción

TradeMind AI es una plataforma de trading con análisis técnico y datos de mercado en tiempo real para Forex y Criptomonedas.

## Características

- **Datos REALES**: Precios de Binance (crypto), OpenExchange (forex), Metals.Live (oro)
- **Actualización**: Cada 4 segundos automáticamente
- **Gráficos TradingView**: Integración completa con gráficos profesionales
- **Señales de Trading**: Recomendaciones BUY/SELL/HOLD con confianza
- **Soporte/Resistencia**: Zonas calculadas automáticamente
- **Temporalidades**: 1D, 1H, 15m

## Activos Soportados

### Forex
- EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD
- XAU/USD (Oro)

### Criptomonedas
- BTC/USD (Bitcoin)
- ETH/USD (Ethereum)

## Instalación

```bash
# Clonar o descargar el proyecto
cd trademind-ai

# Instalar dependencias
npm install

# Iniciar en desarrollo
npm run dev

# Construir para producción
npm run build

# Iniciar en producción
npm start
```

## Despliegue en Vercel

1. Sube el código a GitHub
2. Conecta el repositorio en Vercel
3. Despliega automáticamente

## Tecnologías

- Next.js 15
- React 19
- TypeScript
- Tailwind CSS
- TradingView Widget
- APIs: Binance, OpenExchange, Metals.Live

## Estructura

```
trademind-ai/
├── src/
│   ├── app/
│   │   ├── api/
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/ui/
│   ├── hooks/
│   ├── lib/
│   └── types/
├── public/
├── package.json
└── README.md
```

## Licencia

MIT
